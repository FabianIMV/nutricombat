import { Injectable } from '@nestjs/common';
import {
  WeightCutAnalysisDto,
  WeightCutResponseDto,
  WeightCutSummaryDto,
  EnhancedWeightCutResponseDto,
  RiskAnalysisDto,
  ActionPlanDto,
  ActionPlanSummaryDto,
  NutritionPhaseDto,
  HydrationPhaseDto,
  CardioPlanDto,
  MacronutrientsDto,
  DailyTimelineDto
} from '../common/dto/weight-cut.dto';
import { GeminiWeightCutService } from './gemini-weight-cut.service';

@Injectable()
export class WeightCutService {
  constructor(private readonly geminiWeightCutService: GeminiWeightCutService) {}

  async generateDailyTimeline(
    savedPlan: EnhancedWeightCutResponseDto,
    analysisRequest: WeightCutAnalysisDto,
    startDate: string
  ): Promise<{ dailyTimeline: DailyTimelineDto[] }> {
    try {
      return await this.geminiWeightCutService.generateDailyTimelineFromSavedPlan(
        savedPlan,
        analysisRequest,
        startDate
      );
    } catch (error) {
      console.error('❌ Error in generateDailyTimeline:', error);
      throw new Error(`Failed to generate daily timeline: ${error.message}`);
    }
  }

  // Legacy method for backward compatibility
  analyzeWeightCut(data: WeightCutAnalysisDto): WeightCutResponseDto {
    const { currentWeightKg, targetWeightKg, daysToCut, experienceLevel, model } = data;

    // Calculate basic metrics
    const totalWeightToCutKg = currentWeightKg - targetWeightKg;
    const percentageOfBodyweightToCut = (totalWeightToCutKg / currentWeightKg) * 100;

    // Validate that target weight is lower than current weight
    if (totalWeightToCutKg <= 0) {
      throw new Error('Target weight must be lower than current weight');
    }

    const summary: WeightCutSummaryDto = {
      totalWeightToCutKg: Math.round(totalWeightToCutKg * 100) / 100,
      percentageOfBodyweightToCut: Math.round(percentageOfBodyweightToCut * 100) / 100,
      daysAvailable: daysToCut
    };

    // Determine base risk level
    let baseRiskLevel = this.getBaseRiskLevel(percentageOfBodyweightToCut);

    // Apply contextual adjustments
    const finalRiskCode = this.adjustRiskForContext(
      baseRiskLevel,
      daysToCut,
      experienceLevel,
      percentageOfBodyweightToCut
    );

    // Generate response based on final risk code
    const response = this.generateResponse(finalRiskCode, summary, model);

    return response;
  }

  // New enhanced method that generates detailed action plan using AI
  async analyzeWeightCutWithActionPlan(data: WeightCutAnalysisDto): Promise<EnhancedWeightCutResponseDto> {
    const {
      currentWeightKg,
      targetWeightKg,
      daysToCut,
      experienceLevel,
      trainingSessionsPerWeek,
      trainingSessionsPerDay,
      combatSport
    } = data;

    // Calculate basic metrics
    const totalWeightToCutKg = currentWeightKg - targetWeightKg;
    const percentageOfBodyweightToCut = (totalWeightToCutKg / currentWeightKg) * 100;

    // Validate that target weight is lower than current weight
    if (totalWeightToCutKg <= 0) {
      throw new Error('Target weight must be lower than current weight');
    }

    // Validate combat sport is provided
    if (!combatSport) {
      throw new Error('Combat sport is required for AI-enhanced analysis');
    }

    // Calculate TDEE (Total Daily Energy Expenditure)
    const estimatedTDEE = this.calculateTDEE(currentWeightKg, trainingSessionsPerWeek, trainingSessionsPerDay);

    // Determine base risk level
    let baseRiskLevel = this.getBaseRiskLevel(percentageOfBodyweightToCut);

    // Apply contextual adjustments
    const finalRiskCode = this.adjustRiskForContext(
      baseRiskLevel,
      daysToCut,
      experienceLevel,
      percentageOfBodyweightToCut
    );

    // Generate AI-powered sport-specific plan
    const aiGeneratedPlan = await this.geminiWeightCutService.generateCombatSportWeightCutPlan(
      data,
      estimatedTDEE,
      finalRiskCode
    );

    return aiGeneratedPlan;
  }

  // Fallback method for when AI fails - generates algorithmic plan
  analyzeWeightCutAlgorithmic(data: WeightCutAnalysisDto): EnhancedWeightCutResponseDto {
    const {
      currentWeightKg,
      targetWeightKg,
      daysToCut,
      experienceLevel,
      trainingSessionsPerWeek,
      trainingSessionsPerDay,
      model
    } = data;

    // Calculate basic metrics
    const totalWeightToCutKg = currentWeightKg - targetWeightKg;
    const percentageOfBodyweightToCut = (totalWeightToCutKg / currentWeightKg) * 100;

    // Validate that target weight is lower than current weight
    if (totalWeightToCutKg <= 0) {
      throw new Error('Target weight must be lower than current weight');
    }

    // Calculate TDEE (Total Daily Energy Expenditure)
    const estimatedTDEE = this.calculateTDEE(currentWeightKg, trainingSessionsPerWeek, trainingSessionsPerDay);

    // Determine base risk level
    let baseRiskLevel = this.getBaseRiskLevel(percentageOfBodyweightToCut);

    // Apply contextual adjustments
    const finalRiskCode = this.adjustRiskForContext(
      baseRiskLevel,
      daysToCut,
      experienceLevel,
      percentageOfBodyweightToCut
    );

    // Generate risk analysis
    const riskAnalysis: RiskAnalysisDto = this.generateRiskAnalysis(finalRiskCode);

    // Generate detailed action plan
    const actionPlan: ActionPlanDto = this.generateActionPlan(
      totalWeightToCutKg,
      estimatedTDEE,
      daysToCut,
      currentWeightKg,
      finalRiskCode
    );

    return {
      riskAnalysis,
      actionPlan,
      analysisConfidence: 75, // Lower confidence for algorithmic approach
      modelUsed: model || 'algorithmic-fallback'
    };
  }

  private getBaseRiskLevel(percentageCut: number): string {
    if (percentageCut <= 4) {
      return 'STANDARD';
    } else if (percentageCut > 4 && percentageCut <= 6) {
      return 'AGGRESSIVE';
    } else if (percentageCut > 6 && percentageCut <= 8) {
      return 'HIGH_RISK';
    } else {
      return 'DANGEROUS';
    }
  }

  private adjustRiskForContext(
    baseRisk: string,
    daysToCut: number,
    experienceLevel: string,
    percentageCut: number
  ): string {
    // DANGEROUS always stays DANGEROUS
    if (baseRisk === 'DANGEROUS') {
      return 'DANGEROUS';
    }

    // Upgrade risk if days are too few (less than 5 days)
    if (daysToCut < 5 && baseRisk === 'AGGRESSIVE') {
      return 'HIGH_RISK';
    }

    // Upgrade risk for beginners on aggressive cuts
    if (experienceLevel === 'principiante' && baseRisk === 'AGGRESSIVE') {
      return 'HIGH_RISK';
    }

    return baseRisk;
  }

  private generateResponse(riskCode: string, summary: WeightCutSummaryDto, model?: string): WeightCutResponseDto {
    const responses = {
      STANDARD: {
        title: "Corte de peso estándar y manejable.",
        description: "Este nivel de corte es seguro si se sigue una correcta manipulación de agua y carbohidratos. El riesgo para la salud y el rendimiento es bajo."
      },
      AGGRESSIVE: {
        title: "Corte agresivo para peleadores experimentados.",
        description: "Este es un proceso exigente que requiere disciplina. La rehidratación es crucial para recuperar el rendimiento. Procede con un plan claro y supervisión."
      },
      HIGH_RISK: {
        title: "Alto riesgo debido a condiciones específicas.",
        description: "Este corte presenta riesgos elevados por tu experiencia o tiempo disponible. Se recomienda un objetivo de peso más conservador para tu seguridad."
      },
      DANGEROUS: {
        title: "Peligro: No intentes este corte de peso.",
        description: "Perder más del 8% de tu peso corporal en días puede causar daños graves a la salud. La seguridad es la prioridad número uno. Abandona este objetivo."
      }
    };

    const response: WeightCutResponseDto = {
      riskCode: riskCode as 'STANDARD' | 'AGGRESSIVE' | 'HIGH_RISK' | 'DANGEROUS',
      title: responses[riskCode].title,
      description: responses[riskCode].description,
      summary
    };

    // Add model information if provided
    if (model) {
      response.modelUsed = model;
    }

    return response;
  }

  // Calculate TDEE using Mifflin-St Jeor equation + activity factor
  private calculateTDEE(weightKg: number, sessionsPerWeek: number, sessionsPerDay: number): number {
    // Simplified TDEE calculation for male athletes (assuming male demographics for combat sports)
    // BMR using Mifflin-St Jeor for average 25-year-old, 175cm male athlete
    const bmr = 10 * weightKg + 6.25 * 175 - 5 * 25 + 5;

    // Calculate weekly training sessions
    const totalWeeklyTrainingSessions = sessionsPerWeek * sessionsPerDay;

    // Activity factor based on training intensity
    let activityFactor: number;
    if (totalWeeklyTrainingSessions <= 3) {
      activityFactor = 1.375; // Light activity
    } else if (totalWeeklyTrainingSessions <= 6) {
      activityFactor = 1.55; // Moderate activity
    } else if (totalWeeklyTrainingSessions <= 10) {
      activityFactor = 1.725; // Heavy activity
    } else {
      activityFactor = 1.9; // Extreme activity
    }

    return Math.round(bmr * activityFactor);
  }

  // Generate risk analysis section
  private generateRiskAnalysis(riskCode: string): RiskAnalysisDto {
    const responses = {
      STANDARD: {
        title: "Corte de peso estándar y manejable.",
        description: "Este nivel de corte es seguro si se sigue una correcta manipulación de agua y carbohidratos. El riesgo para la salud y el rendimiento es bajo."
      },
      AGGRESSIVE: {
        title: "Corte agresivo para peleadores experimentados.",
        description: "Este es un proceso exigente que requiere disciplina. La rehidratación es crucial para recuperar el rendimiento. Procede con un plan claro y supervisión."
      },
      HIGH_RISK: {
        title: "Alto riesgo debido a condiciones específicas.",
        description: "Este corte presenta riesgos elevados por tu experiencia o tiempo disponible. Se recomienda un objetivo de peso más conservador para tu seguridad."
      },
      DANGEROUS: {
        title: "Peligro: No intentes este corte de peso.",
        description: "Perder más del 8% de tu peso corporal en días puede causar daños graves a la salud. La seguridad es la prioridad número uno. Abandona este objetivo."
      }
    };

    return {
      riskCode: riskCode as 'STANDARD' | 'AGGRESSIVE' | 'HIGH_RISK' | 'DANGEROUS',
      title: responses[riskCode].title,
      description: responses[riskCode].description
    };
  }

  // Generate comprehensive action plan
  private generateActionPlan(
    totalWeightToCutKg: number,
    estimatedTDEE: number,
    daysToCut: number,
    currentWeightKg: number,
    riskCode: string
  ): ActionPlanDto {
    // Calculate deficit based on risk level
    const targetDeficitCalories = this.calculateTargetDeficit(riskCode, totalWeightToCutKg, daysToCut);

    // Generate summary
    const summary: ActionPlanSummaryDto = {
      totalWeightToCutKg: Math.round(totalWeightToCutKg * 100) / 100,
      estimatedTDEE,
      targetDeficitCalories
    };

    // Generate nutrition plan phases
    const nutritionPlan = this.generateNutritionPlan(estimatedTDEE, targetDeficitCalories, daysToCut, currentWeightKg);

    // Generate hydration plan
    const hydrationPlan = this.generateHydrationPlan(daysToCut);

    // Generate cardio plan
    const cardioPlan = this.generateCardioPlan();

    return {
      summary,
      nutritionPlan,
      hydrationPlan,
      cardioPlan,
      disclaimer: "Este es un plan generado automáticamente y no reemplaza la supervisión de un profesional médico o nutricionista. Monitorea tu salud y detente si experimentas síntomas adversos."
    };
  }

  // Calculate target caloric deficit based on risk and goals
  private calculateTargetDeficit(riskCode: string, totalWeightToCutKg: number, daysToCut: number): number {
    // 1 kg of body weight ≈ 7700 calories
    const totalCaloriesNeeded = totalWeightToCutKg * 7700;
    const dailyDeficitNeeded = totalCaloriesNeeded / daysToCut;

    // Apply safety limits based on risk code
    let maxSafeDeficit: number;
    switch (riskCode) {
      case 'STANDARD':
        maxSafeDeficit = 1000; // Conservative approach
        break;
      case 'AGGRESSIVE':
        maxSafeDeficit = 1500; // Moderate deficit
        break;
      case 'HIGH_RISK':
        maxSafeDeficit = 1200; // Reduced from aggressive due to risk factors
        break;
      case 'DANGEROUS':
        maxSafeDeficit = 800; // Very conservative to minimize damage
        break;
      default:
        maxSafeDeficit = 1000;
    }

    return Math.min(Math.round(dailyDeficitNeeded), maxSafeDeficit);
  }

  // Generate nutrition plan with phases
  private generateNutritionPlan(
    estimatedTDEE: number,
    targetDeficitCalories: number,
    daysToCut: number,
    currentWeightKg: number
  ): NutritionPhaseDto[] {
    const nutritionPlan: NutritionPhaseDto[] = [];

    // Calculate protein and fat requirements
    const proteinGrams = Math.round(currentWeightKg * 2.2); // 2.2g per kg
    const fatGrams = Math.round(currentWeightKg * 0.8); // 0.8g per kg

    // Calculate phase division
    const initialPhaseDays = Math.max(1, Math.floor(daysToCut * 0.6)); // 60% of days
    const depletionPhaseDays = daysToCut - initialPhaseDays; // Remaining days

    // Initial Phase
    const initialPhaseCalories = estimatedTDEE - Math.round(targetDeficitCalories * 0.8); // 80% of deficit
    const initialCarbGrams = Math.round((initialPhaseCalories - (proteinGrams * 4) - (fatGrams * 9)) / 4);

    nutritionPlan.push({
      phase: `Fase Inicial (Primeros ${initialPhaseDays} días de ${daysToCut})`,
      calories: initialPhaseCalories,
      macronutrients: {
        proteinGrams,
        carbGrams: Math.max(50, initialCarbGrams), // Minimum 50g carbs
        fatGrams
      },
      instructions: "Enfócate en proteínas magras y vegetales. Elimina sodio, azúcares y alimentos procesados."
    });

    // Depletion Phase
    if (depletionPhaseDays > 0) {
      const depletionPhaseCalories = estimatedTDEE - targetDeficitCalories; // Full deficit
      const depletionFatGrams = Math.round(currentWeightKg * 0.7); // Slightly reduced fat
      const depletionCarbGrams = Math.round((depletionPhaseCalories - (proteinGrams * 4) - (depletionFatGrams * 9)) / 4);

      nutritionPlan.push({
        phase: `Fase de Depleción (Últimos ${depletionPhaseDays} días)`,
        calories: depletionPhaseCalories,
        macronutrients: {
          proteinGrams,
          carbGrams: Math.max(30, depletionCarbGrams), // Minimum 30g carbs
          fatGrams: depletionFatGrams
        },
        instructions: "Carbohidratos muy bajos, solo de vegetales fibrosos. Mantén la proteína alta."
      });
    }

    return nutritionPlan;
  }

  // Generate hydration plan
  private generateHydrationPlan(daysToCut: number): HydrationPhaseDto[] {
    const hydrationPlan: HydrationPhaseDto[] = [];

    const loadingPhaseDays = Math.max(1, Math.floor(daysToCut * 0.6)); // 60% of days
    const cutPhaseDays = daysToCut - loadingPhaseDays; // Remaining days

    // Water loading phase
    hydrationPlan.push({
      phase: `Carga de Agua (Primeros ${loadingPhaseDays} días)`,
      dailyIntakeLiters: 8,
      instructions: "Bebe constantemente durante el día. Esto preparará a tu cuerpo para eliminar líquidos eficientemente."
    });

    // Water cutting phase
    if (cutPhaseDays > 0) {
      let cutInstruction: string;
      if (cutPhaseDays === 1) {
        cutInstruction = "Reduce a 1L el último día.";
      } else if (cutPhaseDays === 2) {
        cutInstruction = "Reducción progresiva: 3L -> 1L el último día.";
      } else {
        cutInstruction = "Reducción progresiva: 4L -> 2L -> 0.5L el último día.";
      }

      hydrationPlan.push({
        phase: `Corte de Agua (Últimos ${cutPhaseDays} días)`,
        dailyIntakeLiters: cutInstruction,
        instructions: "Reduce la ingesta cada día. El último día, solo sorbos pequeños si es absolutamente necesario."
      });
    }

    return hydrationPlan;
  }

  // Generate cardio plan
  private generateCardioPlan(): CardioPlanDto {
    return {
      saunaSuitRequired: true,
      timing: "Solo en los últimos 2 días, después de tu última sesión de entrenamiento técnico.",
      session: {
        activity: "Trote ligero o bicicleta estática.",
        durationMinutes: 30,
        intensity: "Baja, el objetivo es sudar, no el rendimiento cardiovascular. Mantén un ritmo cardíaco entre 120-140 bpm."
      },
      instructions: "Usa el traje sauna para maximizar la pérdida de agua. Pésate antes y después para monitorear la pérdida. No excedas el tiempo recomendado."
    };
  }
}