import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { NutritionModule } from './nutrition/nutrition.module';
import { WeightCutModule } from './weight-cut/weight-cut.module';
import { UserModule } from './user/user.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    NutritionModule,
    WeightCutModule,
    UserModule,
  ],
})
export class AppModule {}