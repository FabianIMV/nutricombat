import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as hub from "langchain/hub/node";
import { GoogleGenerativeAI } from '@google/generative-ai';
import {
  WeightCutAnalysisDto,
  EnhancedWeightCutResponseDto,
  ActionPlanSummaryDto,
  DailyTimelineDto
} from '../common/dto/weight-cut.dto';

@Injectable()
export class GeminiWeightCutService {
  constructor(private configService: ConfigService) {
    // Set required environment variables for LangChain Hub
    // Note: LangChain Hub already has the Gemini API key configured,
    // so we only need to set the LangSmith API key for accessing prompts
    process.env.LANGSMITH_API_KEY = this.configService.get<string>('LANGSMITH_API_KEY');
    process.env.LANGSMITH_WORKSPACE_ID = this.configService.get<string>('LANGSMITH_WORKSPACE_ID');
  }

  async generateCombatSportWeightCutPlan(
    data: WeightCutAnalysisDto,
    calculatedTDEE: number,
    riskCode: string
  ): Promise<EnhancedWeightCutResponseDto> {
    try {
      const selectedModel = data.model || 'gemini-2.5-flash';

      // Determine which hub prompt to use based on model
      const hubPromptName = selectedModel === 'gemini-2.5-pro' ? 'weightcut' : 'weightcut-flash';

      // Pull the prompt and model from LangChain Hub
      const chainWithModel = await hub.pull(hubPromptName, {
        includeModel: true
      });

      // Build input variables for the prompt
      const inputVariables = this.buildLangChainInputs(data, calculatedTDEE, riskCode);

      // Debug logging
      console.log('🔍 LangChain Hub Debug:', {
        hubPromptName,
        inputVariables,
        hasQuestion: !!inputVariables.question,
        questionType: typeof inputVariables.question,
        questionLength: inputVariables.question?.length
      });

      // Set up timeout for LangChain request (60 seconds)
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('LangChain Hub request timeout after 60 seconds')), 60000);
      });

      // Execute the chain with input variables
      const generatePromise = chainWithModel.invoke(inputVariables);

      // Race between generation and timeout
      const result = await Promise.race([generatePromise, timeoutPromise]) as any;

      // Extract the text response
      const text = result.text || result.content || result;

      // Clean and parse JSON response
      const cleanedResponse = text.replace(/```json|```/g, '').trim();

      try {
        const parsedResponse = JSON.parse(cleanedResponse);

        // Add model information
        parsedResponse.modelUsed = selectedModel;

        // Validate required structure
        if (!parsedResponse.riskAnalysis || !parsedResponse.actionPlan || !parsedResponse.analysisConfidence) {
          throw new Error('Invalid response structure from AI model');
        }

        return parsedResponse;
      } catch (parseError) {
        throw new Error(`Failed to parse AI response as JSON: ${parseError.message}. Response: ${cleanedResponse.substring(0, 500)}...`);
      }

    } catch (error) {
      // Enhanced error logging for debugging
      console.error('LangChain Hub Error Details:', {
        errorMessage: error.message,
        errorType: error.constructor.name,
        timestamp: new Date().toISOString(),
        modelUsed: data.model || 'gemini-2.5-flash',
        combatSport: data.combatSport
      });

      throw new Error(`Error generating AI weight cut plan: ${error.message}`);
    }
  }

  private buildLangChainInputs(
    data: WeightCutAnalysisDto,
    calculatedTDEE: number,
    riskCode: string
  ): Record<string, any> {
    const {
      currentWeightKg,
      targetWeightKg,
      daysToCut,
      userHeight,
      userAge,
      experienceLevel,
      combatSport,
      trainingSessionsPerWeek,
      trainingSessionsPerDay
    } = data;

    const totalWeightToCutKg = currentWeightKg - targetWeightKg;
    const percentageOfBodyweightToCut = (totalWeightToCutKg / currentWeightKg) * 100;

    // Build the question object as JSON string for LangChain Hub
    const questionData = {
      currentWeightKg,
      targetWeightKg,
      daysToCut,
      userHeight,
      userAge,
      experienceLevel,
      combatSport: combatSport || 'muay-thai',
      trainingSessionsPerWeek: trainingSessionsPerWeek || 'No especificado',
      trainingSessionsPerDay: trainingSessionsPerDay || 'No especificado',
      calculatedTDEE,
      riskCode,
      totalWeightToCutKg,
      percentageOfBodyweightToCut: percentageOfBodyweightToCut.toFixed(2)
    };

    // Return variables that the LangChain Hub prompt expects
    return {
      question: JSON.stringify(questionData)
    };
  }

  // Generate daily timeline using Gemini API directly (no LangChain)
  async generateDailyTimelineFromSavedPlan(
    savedPlan: EnhancedWeightCutResponseDto,
    analysisRequest: WeightCutAnalysisDto,
    startDate: string
  ): Promise<{ dailyTimeline: DailyTimelineDto[] }> {
    try {
      const apiKey = this.configService.get<string>('GEMINI_API_KEY');
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

      const totalWeightToCutKg = analysisRequest.currentWeightKg - analysisRequest.targetWeightKg;
      const estimatedTDEE = savedPlan.actionPlan.summary.estimatedTDEE;

      const prompt = this.buildTimelinePrompt(
        savedPlan,
        analysisRequest,
        totalWeightToCutKg,
        estimatedTDEE,
        startDate
      );

      console.log('🔍 Generating daily timeline:', {
        daysToCut: analysisRequest.daysToCut,
        combatSport: analysisRequest.combatSport,
        startDate
      });

      // Timeout dinámico basado en daysToCut (15 segundos por día, mínimo 90s)
      const timeoutMs = Math.max(90000, analysisRequest.daysToCut * 15000);
      console.log(`⏱️  Timeout configurado: ${timeoutMs}ms (${timeoutMs / 1000}s)`);

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Timeline generation timeout after ${timeoutMs / 1000}s`)), timeoutMs)
      );

      const generatePromise = model.generateContent(prompt);
      const result = await Promise.race([generatePromise, timeoutPromise]) as any;

      const response = await result.response;
      const text = response.text();

      // Limpiar y parsear respuesta
      const cleanedResponse = text.replace(/```json|```/g, '').trim();
      const parsed = JSON.parse(cleanedResponse);

      // Validar
      this.validateDailyTimeline(parsed.dailyTimeline, analysisRequest, savedPlan);

      console.log('✅ Timeline generated successfully:', {
        days: parsed.dailyTimeline.length,
        firstDay: parsed.dailyTimeline[0].date,
        lastDay: parsed.dailyTimeline[parsed.dailyTimeline.length - 1].date
      });

      return parsed;

    } catch (error) {
      console.error('❌ Error generating daily timeline:', error);
      throw new Error(`Failed to generate daily timeline: ${error.message}`);
    }
  }

  private buildTimelinePrompt(
    savedPlan: EnhancedWeightCutResponseDto,
    analysisRequest: WeightCutAnalysisDto,
    totalWeightToCutKg: number,
    estimatedTDEE: number,
    startDate: string
  ): string {
    return `Eres un asistente de precisión para planes de corte de peso. Desglosa el plan aprobado en un timeline diario.

PLAN GUARDADO:
${JSON.stringify(savedPlan, null, 2)}

DATOS DEL ATLETA:
${JSON.stringify(analysisRequest, null, 2)}

PARÁMETROS:
- Días totales: ${analysisRequest.daysToCut}
- Peso inicial: ${analysisRequest.currentWeightKg}kg
- Peso objetivo: ${analysisRequest.targetWeightKg}kg
- Peso a perder: ${totalWeightToCutKg}kg
- TDEE: ${estimatedTDEE} cal
- Deporte: ${analysisRequest.combatSport}
- Fecha inicio: ${startDate}

INSTRUCCIONES:

1. FASES: Extrae rangos de días del campo "phase" en nutritionPlan y hydrationPlan.
   Ejemplo: "Fase 1 (Días 1-4)" → días 1,2,3,4 usan esta fase.

2. PESO: Progresión lineal.
   Fórmula: peso día N = ${analysisRequest.currentWeightKg} - (${totalWeightToCutKg} / ${analysisRequest.daysToCut} × (N - 1))

3. CALORÍAS: Usa nutritionPlan[fase].calories como base. Reduce 20-50 cal/día dentro de la fase.

4. MACROS: Usa nutritionPlan[fase].macronutrients. Variación máxima ±5g en la fase.

5. HIDRATACIÓN: Usa hydrationPlan[fase].dailyIntakeLiters (SIEMPRE número). Mantén constante.

6. CARDIO: Interpreta cardioPlan.timing. Asigna durationMinutes solo a esos días, resto = 0.

7. FECHAS: Día 1 = ${startDate}, Día N = fecha + (N-1) días. Formato: "YYYY-MM-DD"

8. RECOMENDACIONES:
   - nutritionFocus: de nutritionPlan[fase].instructions
   - hydrationNote: de hydrationPlan[fase].instructions
   - trainingNote: de sportSpecificRecommendations
   - mealTiming: genera según deporte
   - sleepRecommendation: genera según fase

MAPEO DE FASES:
- "Inicial/Ajuste" → "INITIAL"
- "Depleción/Reducción" → "DEPLETION"
- "Pre-Pesaje/Restricción" → "WATER_CUT"

ESTRUCTURA DE SALIDA (JSON):
{
  "dailyTimeline": [
    {
      "day": 1,
      "date": "${startDate}",
      "phase": "INITIAL",
      "targets": {
        "weightKg": number,
        "caloriesIntake": number,
        "waterIntakeLiters": number,
        "macros": {"proteinGrams": number, "carbGrams": number, "fatGrams": number},
        "cardioMinutes": number,
        "saunaSuitRequired": boolean
      },
      "recommendations": {
        "nutritionFocus": "string",
        "hydrationNote": "string",
        "trainingNote": "string",
        "mealTiming": "string",
        "sleepRecommendation": "string"
      },
      "phaseReference": "string",
      "warnings": []
    }
  ]
}

VALIDACIONES:
✓ Exactamente ${analysisRequest.daysToCut} elementos
✓ day: 1 a ${analysisRequest.daysToCut}
✓ weightKg desciende progresivamente
✓ waterIntakeLiters es number (nunca string)
✓ Último día weightKg ≈ ${analysisRequest.targetWeightKg}kg

Responde SOLO con JSON válido. Sin texto adicional.`;
  }

  private validateDailyTimeline(
    timeline: any[],
    request: WeightCutAnalysisDto,
    savedPlan: EnhancedWeightCutResponseDto
  ) {
    if (!timeline || timeline.length !== request.daysToCut) {
      throw new Error(`Expected ${request.daysToCut} days, got ${timeline?.length || 0}`);
    }

    timeline.forEach((day, idx) => {
      if (day.day !== idx + 1) {
        throw new Error(`Day sequence error at index ${idx}: expected ${idx + 1}, got ${day.day}`);
      }

      if (typeof day.targets.waterIntakeLiters !== 'number') {
        throw new Error(
          `Day ${idx + 1}: waterIntakeLiters must be number, got ${typeof day.targets.waterIntakeLiters}`
        );
      }
    });

    const finalWeight = timeline[timeline.length - 1].targets.weightKg;
    if (Math.abs(finalWeight - request.targetWeightKg) > 0.3) {
      console.warn(
        `⚠️ Final weight ${finalWeight}kg differs from target ${request.targetWeightKg}kg`
      );
    }

    console.log(`✅ Timeline validation passed for ${request.daysToCut} days`);
  }
}