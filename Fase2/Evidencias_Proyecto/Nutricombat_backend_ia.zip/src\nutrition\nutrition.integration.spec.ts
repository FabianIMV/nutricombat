import { Test, TestingModule } from '@nestjs/testing';
import { NutritionController } from './nutrition.controller';
import { GeminiService } from './gemini.service';
import { ConfigModule } from '@nestjs/config';
import { GoogleGenerativeAI } from '@google/generative-ai';

describe('NutritionController Integration', () => {
  let controller: NutritionController;
  let service: GeminiService;

  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          isGlobal: true,
          envFilePath: '.env',
        }),
      ],
      controllers: [NutritionController],
      providers: [GeminiService],
    }).compile();

    controller = module.get<NutritionController>(NutritionController);
    service = module.get<GeminiService>(GeminiService);
  });

  describe('API Connectivity', () => {
    it('should respond to test endpoint', async () => {
      const result = await controller.testEndpoint();

      expect(result).toBeDefined();
      expect(result.message).toBe('Nutrition API is working correctly');
      expect(result.status).toBe('OK');
    });

    it('should connect to Gemini API with gemini-2.0-flash-exp model', async () => {
      // Simple connectivity test to Gemini API
      const apiKey = process.env.GEMINI_API_KEY;
      expect(apiKey).toBeDefined();
      if (!apiKey) {
        throw new Error('GEMINI_API_KEY is not defined');
      }

      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash-exp' });

      // Simple prompt test
      const result = await model.generateContent(['¿Qué color es el cielo?']);
      const response = await result.response;
      const text = response.text();

      expect(text).toBeDefined();
      expect(typeof text).toBe('string');
      expect(text.length).toBeGreaterThan(0);
    }, 15000); // 15 second timeout for API call
  });
});