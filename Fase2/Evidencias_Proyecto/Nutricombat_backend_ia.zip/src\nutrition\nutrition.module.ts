import { Module } from '@nestjs/common';
import { NutritionController } from './nutrition.controller';
import { GeminiService } from './gemini.service';

@Module({
  controllers: [NutritionController],
  providers: [GeminiService],
})
export class NutritionModule {}