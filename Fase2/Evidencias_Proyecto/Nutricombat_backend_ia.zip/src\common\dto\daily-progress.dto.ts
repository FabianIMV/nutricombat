import { IsNumber, IsString, IsOptional, IsBoolean, Min } from 'class-validator';

// DTO para agregar valores acumulativos (lo que el usuario consume/hace en el momento)
export class AddProgressDto {
  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Calories must be non-negative' })
  caloriesConsumed?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Protein must be non-negative' })
  proteinGrams?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Carbs must be non-negative' })
  carbsGrams?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Fats must be non-negative' })
  fatsGrams?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Water must be non-negative' })
  waterLiters?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Cardio minutes must be non-negative' })
  cardioMinutes?: number;

  @IsOptional()
  @IsBoolean()
  saunaSuitUsed?: boolean;

  @IsOptional()
  @IsString()
  notes?: string;
}

// DTO para establecer valores absolutos (sobrescribe, no suma)
export class SetProgressDto {
  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Weight must be positive' })
  actualWeightKg?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Calories must be non-negative' })
  actualCalories?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Protein must be non-negative' })
  actualProteinGrams?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Carbs must be non-negative' })
  actualCarbsGrams?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Fats must be non-negative' })
  actualFatsGrams?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Water must be non-negative' })
  actualWaterLiters?: number;

  @IsOptional()
  @IsNumber()
  @Min(0, { message: 'Cardio minutes must be non-negative' })
  actualCardioMinutes?: number;

  @IsOptional()
  @IsBoolean()
  actualSaunaSuitUsed?: boolean;

  @IsOptional()
  @IsString()
  notes?: string;
}

// DTO de respuesta completa
export class DailyProgressResponseDto {
  id: string;
  dailyTimelineId: string;
  userId: string;
  dayNumber: number;
  trackingDate: string;

  // Targets
  targetWeightKg: number;
  targetCalories: number;
  targetProteinGrams: number;
  targetCarbsGrams: number;
  targetFatsGrams: number;
  targetWaterLiters: number;
  targetCardioMinutes: number;
  targetSaunaSuit: boolean;

  // Actual (valores acumulados del día)
  actualWeightKg?: number;
  actualCalories?: number;
  actualProteinGrams?: number;
  actualCarbsGrams?: number;
  actualFatsGrams?: number;
  actualWaterLiters?: number;
  actualCardioMinutes?: number;
  actualSaunaSuitUsed?: boolean;

  // Varianzas (calculadas automáticamente en DB)
  weightVarianceKg?: number;
  caloriesVariance?: number;
  waterVarianceLiters?: number;

  // Métricas
  complianceScore?: number;
  status: 'pending' | 'in_progress' | 'completed' | 'skipped';
  notes?: string;

  completedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// DTO para estadísticas del progreso
export class ProgressStatisticsDto {
  totalDays: number;
  completedDays: number;
  inProgressDays: number;
  pendingDays: number;
  skippedDays: number;
  avgComplianceScore: number;
  completionRate: number;
  currentStreak: number;
}

// DTO para respuesta del timeline con progreso
export class TimelineWithProgressDto {
  timeline: {
    id: string;
    startDate: string;
    totalDays: number;
    status: string;
  };
  progress: DailyProgressResponseDto[];
  statistics: ProgressStatisticsDto;
}
