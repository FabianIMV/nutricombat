import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  AddProgressDto,
  SetProgressDto,
  DailyProgressResponseDto,
  ProgressStatisticsDto,
  TimelineWithProgressDto,
} from '../common/dto/daily-progress.dto';

@Injectable()
export class DailyProgressService {
  private readonly logger = new Logger(DailyProgressService.name);
  private supabase: SupabaseClient;

  constructor(private configService: ConfigService) {
    const supabaseUrl = this.configService.get<string>('SUPABASE_URL');
    const supabaseKey = this.configService.get<string>('SUPABASE_ANON_KEY');
    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  /**
   * AGREGAR valores acumulativos (SUMA al valor actual)
   * Ejemplo: Usuario registra desayuno 500 cal, luego almuerzo 700 cal
   * Resultado: 500 + 700 = 1200 cal total
   */
  async addProgress(
    userId: string,
    timelineId: string,
    dayNumber: number,
    addDto: AddProgressDto,
  ): Promise<{ success: boolean; data?: DailyProgressResponseDto; error?: string }> {
    try {
      // 1. Obtener el registro actual
      const { data: current, error: fetchError } = await this.supabase
        .from('daily_progress')
        .select('*')
        .eq('daily_timeline_id', timelineId)
        .eq('day_number', dayNumber)
        .eq('user_id', userId)
        .single();

      if (fetchError || !current) {
        return {
          success: false,
          error: 'Progress record not found. Timeline may not be active.',
        };
      }

      // 2. Calcular nuevos valores ACUMULATIVOS (suma)
      const updateData: any = {};

      if (addDto.caloriesConsumed !== undefined) {
        updateData.actual_calories = (current.actual_calories || 0) + addDto.caloriesConsumed;
      }

      if (addDto.proteinGrams !== undefined) {
        updateData.actual_protein_grams = (current.actual_protein_grams || 0) + addDto.proteinGrams;
      }

      if (addDto.carbsGrams !== undefined) {
        updateData.actual_carbs_grams = (current.actual_carbs_grams || 0) + addDto.carbsGrams;
      }

      if (addDto.fatsGrams !== undefined) {
        updateData.actual_fats_grams = (current.actual_fats_grams || 0) + addDto.fatsGrams;
      }

      if (addDto.waterLiters !== undefined) {
        updateData.actual_water_liters = (current.actual_water_liters || 0) + addDto.waterLiters;
      }

      if (addDto.cardioMinutes !== undefined) {
        updateData.actual_cardio_minutes = (current.actual_cardio_minutes || 0) + addDto.cardioMinutes;
      }

      if (addDto.saunaSuitUsed !== undefined) {
        updateData.actual_sauna_suit_used = addDto.saunaSuitUsed;
      }

      // 3. Agregar o concatenar notas
      if (addDto.notes) {
        const timestamp = new Date().toLocaleTimeString('es-ES', {
          hour: '2-digit',
          minute: '2-digit',
        });
        const newNote = `[${timestamp}] ${addDto.notes}`;
        updateData.notes = current.notes
          ? `${current.notes}\n${newNote}`
          : newNote;
      }

      // 4. Actualizar status a in_progress si estaba pending
      if (current.status === 'pending' && Object.keys(updateData).length > 0) {
        updateData.status = 'in_progress';
      }

      // 5. Actualizar en la base de datos (el trigger calculará compliance_score)
      const { data, error } = await this.supabase
        .from('daily_progress')
        .update(updateData)
        .eq('id', current.id)
        .select()
        .single();

      if (error) {
        this.logger.error('Error adding progress:', error);
        return { success: false, error: error.message };
      }

      this.logger.log(
        `Progress added for day ${dayNumber}: +${addDto.caloriesConsumed || 0} cal, +${addDto.waterLiters || 0}L`,
      );

      return { success: true, data };
    } catch (error) {
      this.logger.error('Error in addProgress:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * ESTABLECER valores absolutos (SOBRESCRIBE el valor actual)
   * Usado principalmente para peso y para resetear valores si el usuario se equivocó
   */
  async setProgress(
    userId: string,
    timelineId: string,
    dayNumber: number,
    setDto: SetProgressDto,
  ): Promise<{ success: boolean; data?: DailyProgressResponseDto; error?: string }> {
    try {
      // 1. Obtener el registro actual
      const { data: current, error: fetchError } = await this.supabase
        .from('daily_progress')
        .select('*')
        .eq('daily_timeline_id', timelineId)
        .eq('day_number', dayNumber)
        .eq('user_id', userId)
        .single();

      if (fetchError || !current) {
        return {
          success: false,
          error: 'Progress record not found. Timeline may not be active.',
        };
      }

      // 2. Construir objeto de actualización (valores absolutos)
      const updateData: any = {};

      if (setDto.actualWeightKg !== undefined) {
        updateData.actual_weight_kg = setDto.actualWeightKg;
      }

      if (setDto.actualCalories !== undefined) {
        updateData.actual_calories = setDto.actualCalories;
      }

      if (setDto.actualProteinGrams !== undefined) {
        updateData.actual_protein_grams = setDto.actualProteinGrams;
      }

      if (setDto.actualCarbsGrams !== undefined) {
        updateData.actual_carbs_grams = setDto.actualCarbsGrams;
      }

      if (setDto.actualFatsGrams !== undefined) {
        updateData.actual_fats_grams = setDto.actualFatsGrams;
      }

      if (setDto.actualWaterLiters !== undefined) {
        updateData.actual_water_liters = setDto.actualWaterLiters;
      }

      if (setDto.actualCardioMinutes !== undefined) {
        updateData.actual_cardio_minutes = setDto.actualCardioMinutes;
      }

      if (setDto.actualSaunaSuitUsed !== undefined) {
        updateData.actual_sauna_suit_used = setDto.actualSaunaSuitUsed;
      }

      if (setDto.notes !== undefined) {
        updateData.notes = setDto.notes;
      }

      // 3. Actualizar status a in_progress si estaba pending
      if (current.status === 'pending' && Object.keys(updateData).length > 0) {
        updateData.status = 'in_progress';
      }

      // 4. Actualizar en la base de datos
      const { data, error } = await this.supabase
        .from('daily_progress')
        .update(updateData)
        .eq('id', current.id)
        .select()
        .single();

      if (error) {
        this.logger.error('Error setting progress:', error);
        return { success: false, error: error.message };
      }

      this.logger.log(`Progress set for day ${dayNumber}`);

      return { success: true, data };
    } catch (error) {
      this.logger.error('Error in setProgress:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Obtener el progreso de un día específico
   */
  async getDayProgress(
    userId: string,
    timelineId: string,
    dayNumber: number,
  ): Promise<{ success: boolean; data?: DailyProgressResponseDto; error?: string }> {
    try {
      const { data, error } = await this.supabase
        .from('daily_progress')
        .select('*')
        .eq('daily_timeline_id', timelineId)
        .eq('day_number', dayNumber)
        .eq('user_id', userId)
        .single();

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error) {
      this.logger.error('Error getting day progress:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Obtener el progreso completo del timeline activo
   */
  async getActiveTimelineProgress(
    userId: string,
  ): Promise<{ success: boolean; data?: TimelineWithProgressDto; error?: string }> {
    try {
      // 1. Obtener timeline activo
      const { data: timeline, error: timelineError } = await this.supabase
        .from('daily_timelines')
        .select('id, start_date, total_days, status')
        .eq('user_id', userId)
        .eq('status', 'active')
        .single();

      if (timelineError || !timeline) {
        return { success: false, error: 'No active timeline found' };
      }

      // 2. Obtener todo el progreso
      const { data: progress, error: progressError } = await this.supabase
        .from('daily_progress')
        .select('*')
        .eq('daily_timeline_id', timeline.id)
        .order('day_number', { ascending: true });

      if (progressError) {
        return { success: false, error: progressError.message };
      }

      // 3. Calcular estadísticas
      const statistics = this.calculateStatistics(progress || []);

      return {
        success: true,
        data: {
          timeline: {
            id: timeline.id,
            startDate: timeline.start_date,
            totalDays: timeline.total_days,
            status: timeline.status,
          },
          progress: progress || [],
          statistics,
        },
      };
    } catch (error) {
      this.logger.error('Error getting active timeline progress:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Resetear el progreso de un día (volver a valores null)
   */
  async resetDayProgress(
    userId: string,
    timelineId: string,
    dayNumber: number,
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await this.supabase
        .from('daily_progress')
        .update({
          actual_weight_kg: null,
          actual_calories: null,
          actual_protein_grams: null,
          actual_carbs_grams: null,
          actual_fats_grams: null,
          actual_water_liters: null,
          actual_cardio_minutes: null,
          actual_sauna_suit_used: null,
          compliance_score: null,
          status: 'pending',
          notes: null,
          completed_at: null,
        })
        .eq('daily_timeline_id', timelineId)
        .eq('day_number', dayNumber)
        .eq('user_id', userId);

      if (error) {
        this.logger.error('Error resetting progress:', error);
        return { success: false, error: error.message };
      }

      this.logger.log(`Progress reset for day ${dayNumber}`);
      return { success: true };
    } catch (error) {
      this.logger.error('Error in resetDayProgress:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Marcar un día como completado
   */
  async completeDayProgress(
    userId: string,
    timelineId: string,
    dayNumber: number,
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await this.supabase
        .from('daily_progress')
        .update({
          status: 'completed',
          completed_at: new Date().toISOString(),
        })
        .eq('daily_timeline_id', timelineId)
        .eq('day_number', dayNumber)
        .eq('user_id', userId);

      if (error) {
        return { success: false, error: error.message };
      }

      this.logger.log(`Day ${dayNumber} marked as completed`);
      return { success: true };
    } catch (error) {
      this.logger.error('Error completing day:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Marcar un día como saltado
   */
  async skipDayProgress(
    userId: string,
    timelineId: string,
    dayNumber: number,
    reason?: string,
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await this.supabase
        .from('daily_progress')
        .update({
          status: 'skipped',
          notes: reason || 'Skipped by user',
        })
        .eq('daily_timeline_id', timelineId)
        .eq('day_number', dayNumber)
        .eq('user_id', userId);

      if (error) {
        return { success: false, error: error.message };
      }

      this.logger.log(`Day ${dayNumber} marked as skipped`);
      return { success: true };
    } catch (error) {
      this.logger.error('Error skipping day:', error);
      return { success: false, error: error.message };
    }
  }

  // ========== HELPER METHODS ==========

  private calculateStatistics(progress: any[]): ProgressStatisticsDto {
    if (progress.length === 0) {
      return {
        totalDays: 0,
        completedDays: 0,
        inProgressDays: 0,
        pendingDays: 0,
        skippedDays: 0,
        avgComplianceScore: 0,
        completionRate: 0,
        currentStreak: 0,
      };
    }

    const completed = progress.filter((p) => p.status === 'completed').length;
    const inProgress = progress.filter((p) => p.status === 'in_progress').length;
    const pending = progress.filter((p) => p.status === 'pending').length;
    const skipped = progress.filter((p) => p.status === 'skipped').length;

    const withScores = progress.filter((p) => p.compliance_score !== null);
    const avgScore =
      withScores.length > 0
        ? Math.round(
            withScores.reduce((sum, p) => sum + p.compliance_score, 0) / withScores.length,
          )
        : 0;

    // Calcular racha actual (días consecutivos completados desde el inicio)
    let currentStreak = 0;
    for (const day of progress) {
      if (day.status === 'completed') {
        currentStreak++;
      } else if (day.status !== 'pending') {
        // Si encontramos un día no completado (pero no pending), la racha se rompe
        break;
      }
    }

    return {
      totalDays: progress.length,
      completedDays: completed,
      inProgressDays: inProgress,
      pendingDays: pending,
      skippedDays: skipped,
      avgComplianceScore: avgScore,
      completionRate: Math.round((completed / progress.length) * 100),
      currentStreak,
    };
  }
}
