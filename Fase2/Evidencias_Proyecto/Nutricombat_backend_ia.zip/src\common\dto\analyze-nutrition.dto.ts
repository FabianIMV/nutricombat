import { IsString, IsNotEmpty, IsOptional, IsIn } from 'class-validator';

export class AnalyzeNutritionDto {
  @IsString()
  @IsNotEmpty()
  image: string; // Base64 encoded image

  @IsOptional()
  @IsString()
  @IsIn(['gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-1.5-flash'])
  model?: string; // Optional model selection
}

export class MacronutrientesDto {
  carbohidratos: number;
  proteinas: number;
  grasas: number;
}

export class NutritionResponseDto {
  nombre: string;
  calorias: number;
  peso_estimado_gramos: number;
  macronutrientes: MacronutrientesDto;
  ingredientes: string[];
  confianza_analisis: number;
  modelo_utilizado: string;
}