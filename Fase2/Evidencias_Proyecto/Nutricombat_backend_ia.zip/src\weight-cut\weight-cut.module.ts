import { Module } from '@nestjs/common';
import { WeightCutController } from './weight-cut.controller';
import { WeightCutService } from './weight-cut.service';
import { GeminiWeightCutService } from './gemini-weight-cut.service';
import { SupabaseStorageService } from './supabase-storage.service';
import { DailyProgressService } from './daily-progress.service';

@Module({
  controllers: [WeightCutController],
  providers: [
    WeightCutService,
    GeminiWeightCutService,
    SupabaseStorageService,
    DailyProgressService,
  ],
})
export class WeightCutModule {}