import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';
import 'reflect-metadata';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Configure payload size limits for large base64 images and increased timeout for AI processing
  app.use(require('express').json({
    limit: '5mb',
    extended: true
  }));
  app.use(require('express').urlencoded({
    limit: '5mb',
    extended: true
  }));

  // Configure timeout for AI requests (90 seconds)
  app.use((req, res, next) => {
    // Increase timeout for weight-cut analyze endpoint which uses AI
    if (req.path.includes('/weight-cut/analyze')) {
      req.setTimeout(90000); // 90 seconds
      res.setTimeout(90000); // 90 seconds
    }
    next();
  });

  // Enable CORS for frontend integration
  app.enableCors({
    origin: true,
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
  });

  // Enable validation pipes
  app.useGlobalPipes(new ValidationPipe({
    transform: true,
    whitelist: true,
  }));

  // Global API prefix
  app.setGlobalPrefix('api');

  const port = process.env.PORT || 3000;
  await app.listen(port);
  
  console.log(`🚀 Nutrition API running on: http://localhost:${port}/api`);
  console.log(`📋 Test endpoint: http://localhost:${port}/api/nutrition/test`);
  console.log(`🔍 Analyze endpoint: http://localhost:${port}/api/nutrition/analyze`);
  console.log(`⚖️  Weight Cut endpoint: http://localhost:${port}/api/v1/weight-cut/analyze`);
  console.log(`⏱️  AI requests timeout: 90 seconds`);
}

bootstrap();