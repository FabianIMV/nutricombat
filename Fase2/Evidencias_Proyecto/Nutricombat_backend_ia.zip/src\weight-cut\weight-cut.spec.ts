import { Test, TestingModule } from '@nestjs/testing';
import { WeightCutController } from './weight-cut.controller';
import { WeightCutService } from './weight-cut.service';
import { GeminiWeightCutService } from './gemini-weight-cut.service';
import { ConfigService } from '@nestjs/config';

describe('WeightCutController', () => {
  let controller: WeightCutController;
  let service: WeightCutService;

  beforeEach(async () => {
    // Mock ConfigService for GeminiWeightCutService
    const mockConfigService = {
      get: jest.fn().mockReturnValue('mock-api-key'),
    };

    const module: TestingModule = await Test.createTestingModule({
      controllers: [WeightCutController],
      providers: [
        WeightCutService,
        GeminiWeightCutService,
        { provide: ConfigService, useValue: mockConfigService },
      ],
    }).compile();

    controller = module.get<WeightCutController>(WeightCutController);
    service = module.get<WeightCutService>(WeightCutService);
  });

  describe('analyzeWeightCut (Enhanced)', () => {
    it('should fallback to algorithmic analysis when AI fails', async () => {
      const input = {
        currentWeightKg: 80,
        targetWeightKg: 77,
        daysToCut: 7,
        experienceLevel: 'profesional',
        combatSport: 'boxeo',
        trainingSessionsPerWeek: 5,
        trainingSessionsPerDay: 1
      };

      const result = await controller.analyzeWeightCut(input);

      expect(result.riskAnalysis.riskCode).toBe('STANDARD');
      expect(result.actionPlan.summary.totalWeightToCutKg).toBe(3);
      expect(result.actionPlan.summary.estimatedTDEE).toBeGreaterThan(2000);
      expect(result.analysisConfidence).toBeGreaterThan(0);
      expect(result.modelUsed).toBeDefined();
    });

    it('should throw error for missing combat sport', async () => {
      const input = {
        currentWeightKg: 80,
        targetWeightKg: 76,
        daysToCut: 7,
        experienceLevel: 'profesional',
        trainingSessionsPerWeek: 6,
        trainingSessionsPerDay: 2
        // Missing combatSport
      };

      await expect(controller.analyzeWeightCut(input as any)).rejects.toThrow('Combat sport is required for AI-enhanced analysis');
    });

    it('should handle valid combat sports', async () => {
      const input = {
        currentWeightKg: 80,
        targetWeightKg: 75.5,
        daysToCut: 7,
        experienceLevel: 'principiante',
        combatSport: 'mma',
        trainingSessionsPerWeek: 3,
        trainingSessionsPerDay: 1
      };

      const result = await controller.analyzeWeightCut(input);

      expect(result.riskAnalysis.riskCode).toBe('HIGH_RISK');
      expect(result.analysisConfidence).toBeGreaterThan(0);
      expect(result.modelUsed).toBeDefined();
    });

    it('should work with different combat sports', async () => {
      const validSports = ['boxeo', 'mma', 'muay-thai', 'kickboxing', 'jiu-jitsu'];

      for (const sport of validSports) {
        const input = {
          currentWeightKg: 80,
          targetWeightKg: 77,
          daysToCut: 7,
          experienceLevel: 'profesional',
          combatSport: sport,
          trainingSessionsPerWeek: 5,
          trainingSessionsPerDay: 1
        };

        const result = await controller.analyzeWeightCut(input);
        expect(result.riskAnalysis.riskCode).toBeDefined();
        expect(result.analysisConfidence).toBeGreaterThan(0);
      }
    });

    it('should throw error for missing training data', async () => {
      const input = {
        currentWeightKg: 80,
        targetWeightKg: 77,
        daysToCut: 7,
        experienceLevel: 'profesional',
        combatSport: 'boxeo'
        // Missing trainingSessionsPerWeek and trainingSessionsPerDay
      };

      await expect(controller.analyzeWeightCut(input as any)).rejects.toThrow('Training sessions per week and per day are required for detailed analysis');
    });

    it('should throw error when target weight is higher than current weight', async () => {
      const input = {
        currentWeightKg: 75,
        targetWeightKg: 80,
        daysToCut: 7,
        experienceLevel: 'profesional',
        combatSport: 'boxeo',
        trainingSessionsPerWeek: 5,
        trainingSessionsPerDay: 1
      };

      await expect(controller.analyzeWeightCut(input)).rejects.toThrow('Target weight must be lower than current weight');
    });
  });

  describe('analyzeWeightCutLegacy (Backward Compatibility)', () => {
    it('should work with legacy endpoint for backward compatibility', async () => {
      const input = {
        currentWeightKg: 80,
        targetWeightKg: 77,
        daysToCut: 7,
        experienceLevel: 'profesional'
      };

      const result = await controller.analyzeWeightCutLegacy(input);

      expect(result.riskCode).toBe('STANDARD');
      expect(result.summary.percentageOfBodyweightToCut).toBe(3.75);
      expect(result.summary.totalWeightToCutKg).toBe(3);
    });

    it('should include model information in legacy endpoint', async () => {
      const input = {
        currentWeightKg: 80,
        targetWeightKg: 77,
        daysToCut: 7,
        experienceLevel: 'profesional',
        model: 'gemini-2.5-flash'
      };

      const result = await controller.analyzeWeightCutLegacy(input);

      expect(result.riskCode).toBe('STANDARD');
      expect(result.modelUsed).toBe('gemini-2.5-flash');
    });
  });
});