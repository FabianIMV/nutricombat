import { Controller, Post, Get, Patch, Body, Param, Query, HttpException, HttpStatus, Logger, Delete } from '@nestjs/common';
import { WeightCutService } from './weight-cut.service';
import { SupabaseStorageService } from './supabase-storage.service';
import { DailyProgressService } from './daily-progress.service';
import { WeightCutAnalysisDto, WeightCutResponseDto, EnhancedWeightCutResponseDto, StoreWeightCutDto, ActivateWeightCutDto, DailyTimelineDto } from '../common/dto/weight-cut.dto';
import { AddProgressDto, SetProgressDto } from '../common/dto/daily-progress.dto';

@Controller('v1/weight-cut')
export class WeightCutController {
  private readonly logger = new Logger(WeightCutController.name);

  constructor(
    private readonly weightCutService: WeightCutService,
    private readonly supabaseStorageService: SupabaseStorageService,
    private readonly dailyProgressService: DailyProgressService,
  ) {}

  @Post('analyze')
  async analyzeWeightCut(@Body() weightCutData: WeightCutAnalysisDto): Promise<EnhancedWeightCutResponseDto> {
    try {
      // Validate that target weight is lower than current weight
      if (weightCutData.targetWeightKg >= weightCutData.currentWeightKg) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Invalid weight parameters',
            message: 'Target weight must be lower than current weight',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      // Validate training data is provided
      if (!weightCutData.trainingSessionsPerWeek || !weightCutData.trainingSessionsPerDay) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Missing training data',
            message: 'Training sessions per week and per day are required for detailed analysis',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      // Validate combat sport is provided
      if (!weightCutData.combatSport) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Missing combat sport',
            message: 'Combat sport is required for AI-enhanced analysis',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      // Try AI-enhanced analysis first, fallback to algorithmic if it fails
      try {
        const result = await this.weightCutService.analyzeWeightCutWithActionPlan(weightCutData);
        return result;
      } catch (aiError) {
        console.warn('AI analysis failed, falling back to algorithmic approach:', aiError.message);

        // Fallback to algorithmic analysis
        const fallbackResult = this.weightCutService.analyzeWeightCutAlgorithmic(weightCutData);
        return fallbackResult;
      }
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error analyzing weight cut',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  // Legacy endpoint for backward compatibility
  @Post('analyze-legacy')
  async analyzeWeightCutLegacy(@Body() weightCutData: WeightCutAnalysisDto): Promise<WeightCutResponseDto> {
    try {
      // Validate that target weight is lower than current weight
      if (weightCutData.targetWeightKg >= weightCutData.currentWeightKg) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Invalid weight parameters',
            message: 'Target weight must be lower than current weight',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const result = this.weightCutService.analyzeWeightCut(weightCutData);
      return result;
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error analyzing weight cut',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Post('store')
  async storeWeightCutAnalysis(@Body() storeData: StoreWeightCutDto): Promise<{ success: boolean; id?: string; message: string }> {
    try {
      const result = await this.supabaseStorageService.storeWeightCutAnalysis(
        storeData.analysisRequest,
        storeData.analysisResponse,
        storeData.userId,
      );

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'Storage failed',
            message: result.error || 'Failed to store weight cut analysis',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }

      return {
        success: true,
        id: result.id,
        message: 'Weight cut analysis stored successfully',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error storing weight cut analysis',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get('user/:userId')
  async getUserWeightCutAnalyses(@Param('userId') userId: string) {
    try {
      const result = await this.supabaseStorageService.getUserWeightCutAnalyses(userId);

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'Retrieval failed',
            message: result.error || 'Failed to retrieve weight cut analyses',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }

      return {
        success: true,
        data: result.data,
        message: 'Weight cut analyses retrieved successfully',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error retrieving weight cut analyses',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Patch(':analysisId/status')
  async updateWeightCutStatus(
    @Param('analysisId') analysisId: string,
    @Body('isActive') isActive: boolean,
  ) {
    try {
      if (typeof isActive !== 'boolean') {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Invalid parameter',
            message: 'isActive must be a boolean value',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const result = await this.supabaseStorageService.updateWeightCutActiveStatus(analysisId, isActive);

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'Update failed',
            message: result.error || 'Failed to update weight cut status',
          },
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }

      return {
        success: true,
        message: `Weight cut status updated to ${isActive ? 'active' : 'inactive'}`,
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error updating weight cut status',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get('timeline/:userId')
  async getActiveTimeline(@Param('userId') userId: string) {
    try {
      const result = await this.supabaseStorageService.getActiveDailyTimeline(userId);

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.NOT_FOUND,
            error: 'No active timeline found',
            message: result.error || 'No active daily timeline exists for this user'
          },
          HttpStatus.NOT_FOUND
        );
      }

      return {
        success: true,
        data: result.data,
        message: 'Active timeline retrieved successfully'
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error retrieving timeline',
          message: error.message
        },
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }

  @Post('activate-timeline')
  async activateWeightCutTimeline(
    @Body() activateDto: ActivateWeightCutDto
  ): Promise<{
    success: boolean;
    message: string;
    timeline?: DailyTimelineDto[];
    analysisId?: string;
  }> {
    try {
      // 1. Obtener plan activo del usuario
      const activeResult = await this.supabaseStorageService.getActiveWeightCutByUserId(
        activateDto.userId
      );

      if (!activeResult.success || !activeResult.data) {
        throw new HttpException(
          {
            status: HttpStatus.NOT_FOUND,
            error: 'No active weight cut found',
            message: activeResult.error || 'User must store a weight cut plan first using /store endpoint',
          },
          HttpStatus.NOT_FOUND
        );
      }

      const activePlan = activeResult.data;

      // 2. Verificar si ya existe un timeline activo en daily_timelines
      const existingTimelineResult = await this.supabaseStorageService.getActiveDailyTimeline(
        activateDto.userId
      );

      if (existingTimelineResult.success && existingTimelineResult.data) {
        const existingTimeline = existingTimelineResult.data;

        // Si el timeline existente es para el mismo plan activo, retornarlo
        if (existingTimeline.weight_cut_analysis_id === activePlan.id) {
          return {
            success: true,
            message: 'Timeline already exists for this plan',
            timeline: existingTimeline.timeline_data.days,
            analysisId: activePlan.id,
          };
        }

        // Si el timeline existente es para un plan diferente (no debería pasar por RLS),
        // se cancelará automáticamente al crear el nuevo
        this.logger.log(`Found timeline for different plan. Will be cancelled: ${existingTimeline.id}`);
      }

      // 3. Generar timeline usando Gemini (sin LangChain)
      const timelineResult = await this.weightCutService.generateDailyTimeline(
        activePlan.analysis_response,
        activePlan.analysis_request,
        activateDto.startDate
      );

      // 4. Guardar timeline en la tabla daily_timelines
      const saveResult = await this.supabaseStorageService.storeDailyTimeline(
        activateDto.userId,
        activePlan.id,
        activateDto.startDate,
        timelineResult.dailyTimeline
      );

      if (!saveResult.success) {
        throw new HttpException(
          {
            status: HttpStatus.INTERNAL_SERVER_ERROR,
            error: 'Failed to save timeline',
            message: saveResult.error,
          },
          HttpStatus.INTERNAL_SERVER_ERROR
        );
      }

      return {
        success: true,
        message: 'Weight cut timeline generated and stored successfully',
        timeline: timelineResult.dailyTimeline,
        analysisId: activePlan.id,
      };

    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error activating timeline',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }

  // ==================== DAILY PROGRESS ENDPOINTS ====================

  /**
   * AGREGAR progreso acumulativo (suma valores)
   * Ejemplo: Usuario registra 500 cal de desayuno, luego 700 de almuerzo
   * POST /api/v1/weight-cut/progress/add?userId=1&timelineId=xxx&dayNumber=1
   * Body: { "caloriesConsumed": 500, "waterLiters": 0.5 }
   */
  @Post('progress/add')
  async addDailyProgress(
    @Query('userId') userId: string,
    @Query('timelineId') timelineId: string,
    @Query('dayNumber') dayNumber: string,
    @Body() addDto: AddProgressDto,
  ) {
    try {
      if (!userId || !timelineId || !dayNumber) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Missing required query parameters',
            message: 'userId, timelineId, and dayNumber are required',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const result = await this.dailyProgressService.addProgress(
        userId,
        timelineId,
        parseInt(dayNumber),
        addDto,
      );

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Failed to add progress',
            message: result.error,
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      return {
        success: true,
        data: result.data,
        message: 'Progress added successfully',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error adding progress',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * ESTABLECER progreso absoluto (sobrescribe valores)
   * Usado para peso del día o para corregir valores
   * PATCH /api/v1/weight-cut/progress/set?userId=1&timelineId=xxx&dayNumber=1
   * Body: { "actualWeightKg": 74.5, "actualCalories": 1800 }
   */
  @Patch('progress/set')
  async setDailyProgress(
    @Query('userId') userId: string,
    @Query('timelineId') timelineId: string,
    @Query('dayNumber') dayNumber: string,
    @Body() setDto: SetProgressDto,
  ) {
    try {
      if (!userId || !timelineId || !dayNumber) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Missing required query parameters',
            message: 'userId, timelineId, and dayNumber are required',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const result = await this.dailyProgressService.setProgress(
        userId,
        timelineId,
        parseInt(dayNumber),
        setDto,
      );

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Failed to set progress',
            message: result.error,
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      return {
        success: true,
        data: result.data,
        message: 'Progress set successfully',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error setting progress',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * OBTENER progreso de un día específico
   * GET /api/v1/weight-cut/progress/day?userId=1&timelineId=xxx&dayNumber=1
   */
  @Get('progress/day')
  async getDayProgress(
    @Query('userId') userId: string,
    @Query('timelineId') timelineId: string,
    @Query('dayNumber') dayNumber: string,
  ) {
    try {
      if (!userId || !timelineId || !dayNumber) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Missing required query parameters',
            message: 'userId, timelineId, and dayNumber are required',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const result = await this.dailyProgressService.getDayProgress(
        userId,
        timelineId,
        parseInt(dayNumber),
      );

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.NOT_FOUND,
            error: 'Day progress not found',
            message: result.error,
          },
          HttpStatus.NOT_FOUND,
        );
      }

      return {
        success: true,
        data: result.data,
        message: 'Day progress retrieved successfully',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error retrieving day progress',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * OBTENER todo el progreso del timeline activo
   * GET /api/v1/weight-cut/progress/active/:userId
   */
  @Get('progress/active/:userId')
  async getActiveTimelineProgress(@Param('userId') userId: string) {
    try {
      const result = await this.dailyProgressService.getActiveTimelineProgress(userId);

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.NOT_FOUND,
            error: 'No active progress found',
            message: result.error,
          },
          HttpStatus.NOT_FOUND,
        );
      }

      return {
        success: true,
        data: result.data,
        message: 'Active progress retrieved successfully',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error retrieving active progress',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * RESETEAR progreso de un día (volver a valores null)
   * DELETE /api/v1/weight-cut/progress/reset?userId=1&timelineId=xxx&dayNumber=1
   */
  @Delete('progress/reset')
  async resetDayProgress(
    @Query('userId') userId: string,
    @Query('timelineId') timelineId: string,
    @Query('dayNumber') dayNumber: string,
  ) {
    try {
      if (!userId || !timelineId || !dayNumber) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Missing required query parameters',
            message: 'userId, timelineId, and dayNumber are required',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const result = await this.dailyProgressService.resetDayProgress(
        userId,
        timelineId,
        parseInt(dayNumber),
      );

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Failed to reset progress',
            message: result.error,
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      return {
        success: true,
        message: 'Progress reset successfully',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error resetting progress',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * MARCAR día como completado
   * POST /api/v1/weight-cut/progress/complete?userId=1&timelineId=xxx&dayNumber=1
   */
  @Post('progress/complete')
  async completeDayProgress(
    @Query('userId') userId: string,
    @Query('timelineId') timelineId: string,
    @Query('dayNumber') dayNumber: string,
  ) {
    try {
      if (!userId || !timelineId || !dayNumber) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Missing required query parameters',
            message: 'userId, timelineId, and dayNumber are required',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const result = await this.dailyProgressService.completeDayProgress(
        userId,
        timelineId,
        parseInt(dayNumber),
      );

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Failed to complete day',
            message: result.error,
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      return {
        success: true,
        message: 'Day marked as completed',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error completing day',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * MARCAR día como saltado
   * POST /api/v1/weight-cut/progress/skip?userId=1&timelineId=xxx&dayNumber=1
   * Body: { "reason": "Día de descanso" } (opcional)
   */
  @Post('progress/skip')
  async skipDayProgress(
    @Query('userId') userId: string,
    @Query('timelineId') timelineId: string,
    @Query('dayNumber') dayNumber: string,
    @Body('reason') reason?: string,
  ) {
    try {
      if (!userId || !timelineId || !dayNumber) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Missing required query parameters',
            message: 'userId, timelineId, and dayNumber are required',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const result = await this.dailyProgressService.skipDayProgress(
        userId,
        timelineId,
        parseInt(dayNumber),
        reason,
      );

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Failed to skip day',
            message: result.error,
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      return {
        success: true,
        message: 'Day marked as skipped',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error skipping day',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}