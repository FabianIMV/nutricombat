import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { GoogleGenerativeAI } from '@google/generative-ai';

@Injectable()
export class GeminiService {
  private genAI: GoogleGenerativeAI;

  constructor(private configService: ConfigService) {
    const apiKey = this.configService.get<string>('GEMINI_API_KEY');
    this.genAI = new GoogleGenerativeAI(apiKey);
  }

  async analyzeNutrition(base64Image: string, modelName?: string): Promise<any> {
    try {
      // Select model dynamically, default to gemini-2.5-pro
      const selectedModel = modelName || 'gemini-2.5-pro';
      const model = this.genAI.getGenerativeModel({ model: selectedModel });

      const prompt = `
        Analiza esta imagen de comida y proporciona información nutricional detallada en formato JSON.
        La respuesta debe incluir:
        - nombre del alimento o plato
        - calorías totales estimadas
        - macronutrientes (carbohidratos, proteínas, grasas) en gramos
        - peso estimado de la porción en gramos
        - ingredientes principales identificados (CRÍTICO: cada ingrediente debe ser SOLO el nombre básico del alimento, sin descripciones adicionales, especulaciones o texto entre paréntesis. Responde únicamente con nombres simples y directos)
        - modelo utilizado para el análisis
        
        REGLAS ESTRICTAS PARA INGREDIENTES:
        - NO incluir especulaciones (posiblemente, probablemente, etc.)
        - NO usar paréntesis ni descripciones adicionales

        Asegúrate de que la información sea precisa y esté basada en la imagen proporcionada, tambien usa un estimado de confianza del 0 al 100 sobre la exactitud del analisis, este tiene que ser objetivo y no un valor fijo.

        Responde únicamente con un objeto JSON válido con esta estructura:
        {
          "nombre": "string",
          "calorias": number,
          "peso_estimado_gramos": number,
          "macronutrientes": {
            "carbohidratos": number,
            "proteinas": number,
            "grasas": number
          },
          "ingredientes": ["string"],
          "confianza_analisis": number (0-100),
          "modelo_utilizado": "${selectedModel}"
        }
      `;

      const imagePart = {
        inlineData: {
          data: base64Image,
          mimeType: 'image/jpeg'
        }
      };

      const result = await model.generateContent([prompt, imagePart]);
      const response = await result.response;
      const text = response.text();
      
      // Clean and parse JSON response
      const cleanedResponse = text.replace(/```json|```/g, '').trim();
      return JSON.parse(cleanedResponse);
      
    } catch (error) {
      throw new Error(`Error analyzing nutrition: ${error.message}`);
    }
  }
}