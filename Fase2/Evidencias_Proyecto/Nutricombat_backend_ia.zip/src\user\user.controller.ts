import { Controller, Get, Query, HttpException, HttpStatus } from '@nestjs/common';
import { UserService } from './user.service';

@Controller('v1/user_id')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get('user-id')
  async getUserIdByEmail(@Query('email') email: string): Promise<{ success: boolean; userId?: string; message: string }> {
    try {
      if (!email) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'Missing email parameter',
            message: 'Email query parameter is required',
          },
          HttpStatus.BAD_REQUEST,
        );
      }

      const result = await this.userService.getUserIdByEmail(email);

      if (!result.success) {
        throw new HttpException(
          {
            status: HttpStatus.NOT_FOUND,
            error: 'User not found',
            message: result.error || 'Failed to retrieve user ID',
          },
          HttpStatus.NOT_FOUND,
        );
      }

      return {
        success: true,
        userId: result.userId,
        message: 'User ID retrieved successfully',
      };
    } catch (error) {
      if (error instanceof HttpException) {
        throw error;
      }

      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error retrieving user ID',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
