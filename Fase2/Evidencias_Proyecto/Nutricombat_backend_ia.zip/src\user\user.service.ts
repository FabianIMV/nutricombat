import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

@Injectable()
export class UserService {
  private readonly logger = new Logger(UserService.name);
  private supabase: SupabaseClient;

  constructor(private configService: ConfigService) {
    const supabaseUrl = this.configService.get<string>('SUPABASE_URL');
    const supabaseKey = this.configService.get<string>('SUPABASE_ANON_KEY');

    if (!supabaseUrl || !supabaseKey) {
      this.logger.warn('Supabase configuration not found. User service functionality will be disabled.');
      return;
    }

    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.logger.log('Supabase client initialized successfully for User service');
  }

  async getUserIdByEmail(email: string): Promise<{ success: boolean; userId?: string; error?: string }> {
    if (!this.supabase) {
      return {
        success: false,
        error: 'Supabase client not initialized. Check your configuration.',
      };
    }

    try {
      this.logger.log(`Searching for user with email: ${email}`);

      const { data, error } = await this.supabase
        .from('profiles')
        .select('id')
        .eq('email', email);

      this.logger.log(`Query result - data: ${JSON.stringify(data)}, error: ${JSON.stringify(error)}`);

      if (error) {
        this.logger.error('Failed to retrieve user by email:', error);
        return {
          success: false,
          error: `Database error: ${error.message}`,
        };
      }

      if (!data || data.length === 0) {
        this.logger.warn('No user found with this email');
        return {
          success: false,
          error: 'User not found',
        };
      }

      this.logger.log(`User found with id: ${data[0].id}`);

      return {
        success: true,
        userId: String(data[0].id),
      };
    } catch (error) {
      this.logger.error('Unexpected error retrieving user by email:', error);
      return {
        success: false,
        error: `Unexpected error: ${error.message}`,
      };
    }
  }
}
