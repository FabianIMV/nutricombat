import { Controller, Post, Get, Body, HttpException, HttpStatus } from '@nestjs/common';
import { GeminiService } from './gemini.service';
import { AnalyzeNutritionDto, NutritionResponseDto } from '../common/dto/analyze-nutrition.dto';

@Controller('nutrition')
export class NutritionController {
  constructor(private readonly geminiService: GeminiService) {}

  @Post('analyze')
  async analyzeNutrition(@Body() analyzeNutritionDto: AnalyzeNutritionDto): Promise<NutritionResponseDto> {
    try {
      // Remove data URL prefix if present (data:image/jpeg;base64,)
      const base64Image = analyzeNutritionDto.image.replace(/^data:image\/[a-z]+;base64,/, '');
      
      const result = await this.geminiService.analyzeNutrition(base64Image, analyzeNutritionDto.model);
      return result;
    } catch (error) {
      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: 'Error analyzing nutrition information',
          message: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get('test')
  async testEndpoint(): Promise<{ message: string; status: string }> {
    return {
      message: 'Nutrition API is working correctly',
      status: 'OK'
    };
  }
}