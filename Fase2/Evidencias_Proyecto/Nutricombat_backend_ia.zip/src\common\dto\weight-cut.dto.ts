import { IsNumber, IsString, IsNotEmpty, IsIn, Min, IsOptional, Max } from 'class-validator';

export class WeightCutAnalysisDto {
  @IsNumber()
  @Min(30, { message: 'Current weight must be at least 30kg' })
  currentWeightKg: number;

  @IsNumber()
  @Min(30, { message: 'Target weight must be at least 30kg' })
  targetWeightKg: number;

  @IsNumber()
  @Min(1, { message: 'Days to cut must be at least 1' })
  daysToCut: number;

  @IsNumber()
  @Min(100, { message: 'Height must be at least 100cm' })
  @Max(250, { message: 'Height cannot exceed 250cm' })
  userHeight: number;

  @IsNumber()
  @Min(15, { message: 'Age must be at least 15' })
  @Max(65, { message: 'Age cannot exceed 65' })
  userAge: number;

  @IsString()
  @IsNotEmpty()
  @IsIn(['principiante', 'amateur', 'profesional'])
  experienceLevel: string;

  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @IsIn(['boxeo', 'mma', 'muay-thai', 'kickboxing', 'jiu-jitsu', 'judo', 'karate', 'taekwondo', 'lucha'])
  combatSport?: string;

  @IsOptional()
  @IsNumber()
  @Min(1, { message: 'Training sessions per week must be at least 1' })
  @Max(7, { message: 'Training sessions per week cannot exceed 7' })
  trainingSessionsPerWeek?: number;

  @IsOptional()
  @IsNumber()
  @Min(1, { message: 'Training sessions per day must be at least 1' })
  @Max(3, { message: 'Training sessions per day cannot exceed 3' })
  trainingSessionsPerDay?: number;

  @IsOptional()
  @IsString()
  @IsIn(['gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-1.5-flash'])
  model?: string;
}

// Legacy DTOs for backward compatibility
export class WeightCutSummaryDto {
  totalWeightToCutKg: number;
  percentageOfBodyweightToCut: number;
  daysAvailable: number;
}

export class WeightCutResponseDto {
  riskCode: 'STANDARD' | 'AGGRESSIVE' | 'HIGH_RISK' | 'DANGEROUS';
  title: string;
  description: string;
  summary: WeightCutSummaryDto;
  modelUsed?: string;
}

// New enhanced DTOs for the detailed action plan
export class RiskAnalysisDto {
  riskCode: 'STANDARD' | 'AGGRESSIVE' | 'HIGH_RISK' | 'DANGEROUS';
  title: string;
  description: string;
}

export class ActionPlanSummaryDto {
  totalWeightToCutKg: number;
  estimatedTDEE: number;
  targetDeficitCalories: number;
}

export class MacronutrientsDto {
  proteinGrams: number;
  carbGrams: number;
  fatGrams: number;
}

export class NutritionPhaseDto {
  phase: string;
  calories: number;
  macronutrients: MacronutrientsDto;
  instructions: string;
}

export class HydrationPhaseDto {
  phase: string;
  dailyIntakeLiters: number | string;
  instructions: string;
}

export class CardioSessionDto {
  activity: string;
  durationMinutes: number;
  intensity: string;
}

export class CardioPlanDto {
  saunaSuitRequired: boolean;
  timing: string;
  session: CardioSessionDto;
  instructions: string;
}

export class ActionPlanDto {
  summary: ActionPlanSummaryDto;
  nutritionPlan: NutritionPhaseDto[];
  hydrationPlan: HydrationPhaseDto[];
  cardioPlan: CardioPlanDto;
  sportSpecificRecommendations?: string[];
  disclaimer: string;
}

export class EnhancedWeightCutResponseDto {
  riskAnalysis: RiskAnalysisDto;
  actionPlan: ActionPlanDto;
  analysisConfidence: number; // 1-100 scale
  modelUsed: string;
}

export class StoreWeightCutDto {
  @IsString()
  @IsNotEmpty()
  userId: string;

  @IsNotEmpty()
  analysisRequest: WeightCutAnalysisDto;

  @IsNotEmpty()
  analysisResponse: EnhancedWeightCutResponseDto;
}

// DTO for activating weight cut timeline
export class ActivateWeightCutDto {
  @IsString()
  @IsNotEmpty()
  userId: string;

  @IsString()
  @IsNotEmpty()
  startDate: string; // Format: YYYY-MM-DD
}

// DTO for daily timeline
export class DailyTimelineDto {
  day: number;
  date: string;
  phase: 'INITIAL' | 'DEPLETION' | 'WATER_CUT' | 'FINAL';
  targets: {
    weightKg: number;
    caloriesIntake: number;
    waterIntakeLiters: number;
    macros: MacronutrientsDto;
    cardioMinutes: number;
    saunaSuitRequired: boolean;
  };
  recommendations: {
    nutritionFocus: string;
    hydrationNote: string;
    trainingNote: string;
    mealTiming: string;
    sleepRecommendation: string;
  };
  phaseReference: string;
  warnings: string[];
}