import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { EnhancedWeightCutResponseDto, WeightCutAnalysisDto } from '../common/dto/weight-cut.dto';

export interface WeightCutRecord {
  id?: string;
  user_id?: string;
  analysis_request: WeightCutAnalysisDto;
  analysis_response: EnhancedWeightCutResponseDto;
  is_active?: boolean;
  daily_timeline?: any[];
  started_at?: string;
  created_at?: string;
  updated_at?: string;
}

export interface DailyTimelineRecord {
  id?: string;
  user_id: string;
  weight_cut_analysis_id: string;
  start_date: string;
  total_days: number;
  status?: 'active' | 'completed' | 'cancelled';
  timeline_data: any; // JSONB con el array de días
  current_day?: number;
  last_updated_day?: string;
  created_at?: string;
  updated_at?: string;
  completed_at?: string;
}

@Injectable()
export class SupabaseStorageService {
  private readonly logger = new Logger(SupabaseStorageService.name);
  private supabase: SupabaseClient;

  constructor(private configService: ConfigService) {
    const supabaseUrl = this.configService.get<string>('SUPABASE_URL');
    const supabaseKey = this.configService.get<string>('SUPABASE_ANON_KEY');

    if (!supabaseUrl || !supabaseKey) {
      this.logger.warn('Supabase configuration not found. Storage functionality will be disabled.');
      return;
    }

    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.logger.log('Supabase client initialized successfully');
  }

  async storeWeightCutAnalysis(
    analysisRequest: WeightCutAnalysisDto,
    analysisResponse: EnhancedWeightCutResponseDto,
    userId?: string,
  ): Promise<{ success: boolean; id?: string; error?: string }> {
    if (!this.supabase) {
      return {
        success: false,
        error: 'Supabase client not initialized. Check your configuration.',
      };
    }

    try {
      // First, deactivate all active weight cuts for this user
      if (userId) {
        const { error: deactivateError } = await this.supabase
          .from('weight_cut_analyses')
          .update({ is_active: false })
          .eq('user_id', userId)
          .eq('is_active', true);

        if (deactivateError) {
          this.logger.warn('Failed to deactivate previous weight cuts:', deactivateError);
          // Continue anyway - this is not critical
        } else {
          this.logger.log(`Deactivated all active weight cuts for user ${userId}`);
        }
      }

      const record: WeightCutRecord = {
        user_id: userId,
        analysis_request: analysisRequest,
        analysis_response: analysisResponse,
        is_active: true, // New record is always active
      };

      this.logger.log('Attempting to store record:', JSON.stringify(record, null, 2));

      const { data, error } = await this.supabase
        .from('weight_cut_analyses')
        .insert([record])
        .select('id')
        .single();

      if (error) {
        this.logger.error('Failed to store weight cut analysis:', error);
        return {
          success: false,
          error: `Database error: ${error.message}`,
        };
      }

      this.logger.log(`Weight cut analysis stored successfully with ID: ${data.id}`);
      return {
        success: true,
        id: data.id,
      };
    } catch (error) {
      this.logger.error('Unexpected error storing weight cut analysis:', error);
      return {
        success: false,
        error: `Unexpected error: ${error.message}`,
      };
    }
  }

  async getWeightCutAnalysis(id: string): Promise<{ success: boolean; data?: WeightCutRecord; error?: string }> {
    if (!this.supabase) {
      return {
        success: false,
        error: 'Supabase client not initialized. Check your configuration.',
      };
    }

    try {
      const { data, error } = await this.supabase
        .from('weight_cut_analyses')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        this.logger.error('Failed to retrieve weight cut analysis:', error);
        return {
          success: false,
          error: `Database error: ${error.message}`,
        };
      }

      return {
        success: true,
        data,
      };
    } catch (error) {
      this.logger.error('Unexpected error retrieving weight cut analysis:', error);
      return {
        success: false,
        error: `Unexpected error: ${error.message}`,
      };
    }
  }

  async getUserWeightCutAnalyses(userId: string): Promise<{ success: boolean; data?: WeightCutRecord[]; error?: string }> {
    if (!this.supabase) {
      return {
        success: false,
        error: 'Supabase client not initialized. Check your configuration.',
      };
    }

    try {
      const { data, error } = await this.supabase
        .from('weight_cut_analyses')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        this.logger.error('Failed to retrieve user weight cut analyses:', error);
        return {
          success: false,
          error: `Database error: ${error.message}`,
        };
      }

      return {
        success: true,
        data: data || [],
      };
    } catch (error) {
      this.logger.error('Unexpected error retrieving user weight cut analyses:', error);
      return {
        success: false,
        error: `Unexpected error: ${error.message}`,
      };
    }
  }

  async updateWeightCutActiveStatus(
    analysisId: string,
    isActive: boolean,
  ): Promise<{ success: boolean; error?: string }> {
    if (!this.supabase) {
      return {
        success: false,
        error: 'Supabase client not initialized. Check your configuration.',
      };
    }

    try {
      const { error } = await this.supabase
        .from('weight_cut_analyses')
        .update({ is_active: isActive })
        .eq('id', analysisId);

      if (error) {
        this.logger.error('Failed to update weight cut active status:', error);
        return {
          success: false,
          error: `Database error: ${error.message}`,
        };
      }

      this.logger.log(`Weight cut analysis ${analysisId} active status updated to ${isActive}`);
      return {
        success: true,
      };
    } catch (error) {
      this.logger.error('Unexpected error updating weight cut active status:', error);
      return {
        success: false,
        error: `Unexpected error: ${error.message}`,
      };
    }
  }

  async getActiveWeightCutByUserId(userId: string): Promise<{
    success: boolean;
    data?: WeightCutRecord;
    error?: string;
  }> {
    if (!this.supabase) {
      return { success: false, error: 'Supabase not initialized' };
    }

    try {
      const { data, error } = await this.supabase
        .from('weight_cut_analyses')
        .select('*')
        .eq('user_id', userId)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        this.logger.error('Failed to get active weight cut:', error);
        return { success: false, error: error.message };
      }

      if (!data) {
        return { success: false, error: 'No active weight cut found for user' };
      }

      this.logger.log(`✅ Active weight cut found for user ${userId}: ${data.id}`);
      return { success: true, data };

    } catch (error) {
      this.logger.error('Unexpected error getting active weight cut:', error);
      return { success: false, error: error.message };
    }
  }

  async activateWeightCutWithTimeline(
    analysisId: string,
    dailyTimeline: any[],
    startDate: string
  ): Promise<{ success: boolean; error?: string }> {
    if (!this.supabase) {
      return { success: false, error: 'Supabase not initialized' };
    }

    try {
      const { error } = await this.supabase
        .from('weight_cut_analyses')
        .update({
          daily_timeline: dailyTimeline,
          started_at: startDate
        })
        .eq('id', analysisId);

      if (error) {
        this.logger.error('Failed to activate timeline:', error);
        return { success: false, error: error.message };
      }

      this.logger.log(`✅ Timeline activated for analysis ${analysisId} with ${dailyTimeline.length} days`);
      return { success: true };

    } catch (error) {
      this.logger.error('Unexpected error activating timeline:', error);
      return { success: false, error: error.message };
    }
  }

  async storeDailyTimeline(
    userId: string,
    weightCutAnalysisId: string,
    startDate: string,
    dailyTimeline: any[]
  ): Promise<{ success: boolean; id?: string; error?: string }> {
    if (!this.supabase) {
      return { success: false, error: 'Supabase not initialized' };
    }

    try {
      // Primero, desactivar cualquier timeline activo previo del usuario
      const { error: deactivateError } = await this.supabase
        .from('daily_timelines')
        .update({ status: 'cancelled' })
        .eq('user_id', userId)
        .eq('status', 'active');

      if (deactivateError) {
        this.logger.warn('Failed to deactivate previous timelines:', deactivateError);
      } else {
        this.logger.log(`Deactivated previous active timelines for user ${userId}`);
      }

      // Crear el nuevo registro
      const record: DailyTimelineRecord = {
        user_id: userId,
        weight_cut_analysis_id: weightCutAnalysisId,
        start_date: startDate,
        total_days: dailyTimeline.length,
        status: 'active',
        timeline_data: { days: dailyTimeline },
        current_day: 1,
      };

      const { data, error } = await this.supabase
        .from('daily_timelines')
        .insert([record])
        .select('id')
        .single();

      if (error) {
        this.logger.error('Failed to store daily timeline:', error);
        return { success: false, error: `Database error: ${error.message}` };
      }

      this.logger.log(`✅ Daily timeline stored successfully with ID: ${data.id}`);
      return { success: true, id: data.id };

    } catch (error) {
      this.logger.error('Unexpected error storing daily timeline:', error);
      return { success: false, error: `Unexpected error: ${error.message}` };
    }
  }

  async getActiveDailyTimeline(userId: string): Promise<{
    success: boolean;
    data?: DailyTimelineRecord;
    error?: string;
  }> {
    if (!this.supabase) {
      return { success: false, error: 'Supabase not initialized' };
    }

    try {
      const { data, error } = await this.supabase
        .from('daily_timelines')
        .select('*')
        .eq('user_id', userId)
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        this.logger.error('Failed to get active daily timeline:', error);
        return { success: false, error: error.message };
      }

      if (!data) {
        return { success: false, error: 'No active daily timeline found for user' };
      }

      this.logger.log(`✅ Active daily timeline found for user ${userId}: ${data.id}`);
      return { success: true, data };

    } catch (error) {
      this.logger.error('Unexpected error getting active daily timeline:', error);
      return { success: false, error: error.message };
    }
  }
}