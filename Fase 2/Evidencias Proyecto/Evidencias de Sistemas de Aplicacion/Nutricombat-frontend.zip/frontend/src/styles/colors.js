export const COLORS = {
  primary: '#1a1a2e',
  secondary: '#00d4aa',
  accent: '#16213e',
  text: '#ffffff',
  textSecondary: '#b0b0b0',
  error: '#ff6b6b'
};